# -*- coding: utf-8 -*-
"""
Created on Fri Nov 27 09:51:07 2020

@author: myersau3
"""

import cProfile

cProfile.run(filename = 'SLSP.py')